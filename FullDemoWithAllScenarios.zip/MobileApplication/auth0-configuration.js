const config = {
  clientId: "wKiZlChwLvToPnlgMkehL8IYxQvBXxQM",
  domain: "jacoblogin.acmetest.org"
};

export default config;