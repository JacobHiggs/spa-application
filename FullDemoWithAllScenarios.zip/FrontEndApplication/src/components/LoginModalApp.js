import React, { useState } from 'react';

const LoginModal2 = () => {
  const [showModal, setShowModal] = useState(false);
  const [showModalCode, setShowModalCode] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    setError('');
    const clientId = 'Sflii0gup2Gjg65gsmj6Yfrs737BbVml'; // Replace with your Auth0 client ID
    const domain = 'jacoblogin.acmetest.org'; // Replace with your Auth0 domain
    const audience = ''; // Optional
    const scope = 'openid profile email'; // Customize as needed

    try {
      const res = await fetch(`http://localhost:3003/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          loginForm: "loginForm"
        })
      });

      const data = await res.json();

      if (res.ok) {
        setShowModal(false);
        setShowModalCode(true);
      } else {
        setError(data.error_description || 'Login failed.');
      }
    } catch (err) {
      console.error(err);
      setError('An error occurred.');
    }
  };

  const handleCode = async () => {
    setError('');
    const clientId = 'Sflii0gup2Gjg65gsmj6Yfrs737BbVml'; // Replace with your Auth0 client ID
    const domain = 'jacoblogin.acmetest.org'; // Replace with your Auth0 domain
    const audience = ''; // Optional
    const scope = 'openid profile email'; // Customize as needed

    try {
      const res = await fetch(`http://localhost:3003/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          code: password,
          loginForm: "loginForm"
        })
      });

      const data = await res.json();

      if (res.ok) {
        alert('Login Status: ' + data.loginStatus);
        setShowModalCode(false);
      } else {
        setError(data.error_description || 'Login failed.');
      }
    } catch (err) {
      console.error(err);
      setError('An error occurred.');
    }
  };

  return (
    <>
      <button onClick={() => setShowModal(true)}>Login with Modal Scenario2C</button>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>Login</h3>
            <input
              type="text"
              placeholder="Phone Number"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <br></br>
            <button onClick={handleLogin}>Submit</button>
            <br></br>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <button onClick={() => setShowModal(false)}>Cancel</button>
            <br></br>
          </div>
        </div>
      )}
      {showModalCode && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>Login</h3>
            <input
              type="text"
              placeholder="Phone Number"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <br></br>
            <input
              type="password"
              placeholder="Code"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <br></br>
            <button onClick={handleCode}>Submit</button>
            <br></br>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <button onClick={() => setShowModalCode(false)}>Cancel</button>
            <br></br>
          </div>
        </div>
      )}
    </>
  );
};

export default LoginModal2;