/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import { Alert, Button, StyleSheet, Text, View, Linking } from 'react-native';
import { useAuth0, Auth0Provider } from 'react-native-auth0';
import config from './auth0-configuration';
import { WebView } from 'react-native-webview';

const Home = () => {
  const [showWebView, setShowWebView] = useState(false);
  const [showWebViewNormal, setShowWebViewNormal] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false); // Track if login is in progress
  const [webViewUrl, setWebViewUrl] = useState('https://jacobhiggs.github.io/spa-application/');
  const [showWebViewSessionToken, setWebViewSessionToken] = useState(false);
  const [sessionToken, setSessionToken] = useState('');
  const { authorize, clearSession, user, getCredentials, error, isLoading } = useAuth0();

  const onLogin = async () => {
    try {
      setIsLoggingIn(true); // Start the login process
      await authorize({
        scope: 'openid profile email offline_access'
      }, {});
      const credentials = await getCredentials();

      Alert.alert('AccessToken: ' + credentials?.accessToken);
      Alert.alert('RefreshToken: ' + credentials?.refreshToken);
      setIsLoggingIn(false); // Login successful, stop tracking the login state
    } catch (err) {
      setIsLoggingIn(false); // Stop tracking login state on error
      Alert.alert('Login Failed', err.message);
    }
  };

  const onLoginAndSession = async () => {
    try {
      setIsLoggingIn(true); // Start the login process
      await authorize({
        scope: 'openid profile email offline_access'
      }, {});
      const credentials = await getCredentials();

      Alert.alert('AccessToken: ' + credentials?.accessToken);
      Alert.alert('RefreshToken: ' + credentials?.refreshToken);
      setIsLoggingIn(false); // Login successful, stop tracking the login state

      try {

        const response = await fetch('https://jacoblogin.acmetest.org/oauth/token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            grant_type: 'refresh_token',
            client_id: 'wKiZlChwLvToPnlgMkehL8IYxQvBXxQM',
            refresh_token: '' + credentials?.refreshToken,
            audience: 'urn:jacoblogin.acmetest.org:session_transfer',
          }).toString(),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error_description || 'Failed to refresh token');
        }

        setSessionToken(data.access_token);
        setWebViewUrl(`https://jacobhiggs.github.io/spa-application/?session_token=` + data.access_token);
        Alert.alert('Session Transfer Token: ' + data.access_token);

      } catch (error) {
        Alert.alert('Error refreshing token:', error.message);
      }

    } catch (err) {
      setIsLoggingIn(false); // Stop tracking login state on error
      Alert.alert('Login Failed', err.message);
    }
  };

  const onLogout = async () => {
    await clearSession({}, {});
  };

  const openInSafari = () => {
    Linking.openURL('https://jacobhiggs.github.io/spa-application/');
  };

  const openInWebView = () => {
    setShowWebView(!showWebView);
  };

  const openInWebViewNormal = () => {
    setShowWebViewNormal(!showWebViewNormal);
  };

  const openInWebViewWithToken = async () => {
    // If already open, toggle it off
    if (showWebViewSessionToken) {
      setWebViewSessionToken(false);
      setSessionToken('');
      return;
    }

    try {
      const credentials = await getCredentials();

      const response = await fetch('https://jacoblogin.acmetest.org/oauth/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          client_id: 'wKiZlChwLvToPnlgMkehL8IYxQvBXxQM',
          refresh_token: '' + credentials?.refreshToken,
          audience: 'urn:jacoblogin.acmetest.org:session_transfer',
        }).toString(),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error_description || 'Failed to refresh token');
      }

      setSessionToken(data.access_token);
      setWebViewSessionToken(true);
      Alert.alert('Session Transfer Token: ' + data.access_token);

    } catch (error) {
      Alert.alert('Error refreshing token:', error.message);
    }
  };

  const loggedIn = user !== undefined && user !== null;

  if (isLoading) {
    return (
      <View style={styles.container}>
        <Text>Loading</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}> Auth0Sample - Login </Text>
      {user && <Text>You are logged in as {user.name}</Text>}
      {!user && <Text>You are not logged in</Text>}
      <Button
        onPress={loggedIn ? onLogout : onLogin}
        title={loggedIn ? 'Log Out' : 'Log In'}
      />
      {error && <Text style={styles.error}>{error.message}</Text>}

      {/* Buttons */}
      <Button title="Open Web Application in Safari" onPress={openInSafari} />
      <Button
        title={showWebViewNormal ? 'Close Web Application in WebView (Won\'t work)' : 'Open Web Application in WebView (Won\'t work)'}
        onPress={openInWebViewNormal}
      />
      <Button
        title={showWebView ? 'Close Web Application in WebView Tracking Restricted' : 'Open Web Application in WebView Tracking Restricted'}
        onPress={openInWebView}
      />
      <Button
        title={showWebViewSessionToken ? 'Close Web Application in WebView with Session Token' : 'Open Web Application in WebView with Session Token'}
        onPress={openInWebViewWithToken}
      />

      {showWebView && (
        <View style={styles.webviewContainer}>
          <WebView
            source={{ uri: webViewUrl }} // Use webViewUrl instead of directly using the URL in WebView
            originWhitelist={['*']}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            onShouldStartLoadWithRequest={(request) => {
              const url = request.url;
              const isRestricted = url.includes('/restricted.html');

              if (isRestricted && !loggedIn && !isLoggingIn) {
                Alert.alert('Restricted Page', 'You must be logged in to access this page.');
                setIsLoggingIn(true); // Start the login process

                // Trigger the login process
                onLoginAndSession();

                return false; // Prevent navigation to restricted page
              }

              return true; // Allow all other navigations
            }}
          />
        </View>
      )}

      {/* Normal WebView */}
      {showWebViewNormal && (
        <View style={styles.webviewContainer}>
          <WebView source={{ uri: `https://jacobhiggs.github.io/spa-application/` }} />
        </View>
      )}


      {/* WebView with session token */}
      {showWebViewSessionToken && sessionToken !== '' && (
        <View style={styles.webviewContainer}>
          <WebView source={{ uri: `https://jacobhiggs.github.io/spa-application/?session_token=${sessionToken}` }} />
        </View>
      )}
    </View>
  );
};

const App = () => {
  return (
    <Auth0Provider domain={config.domain} clientId={config.clientId}>
      <Home />
    </Auth0Provider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
    padding: 10,
  },
  header: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  error: {
    margin: 20,
    textAlign: 'center',
    color: '#D8000C',
  },
  webviewContainer: {
    width: '100%',
    height: 400,
    marginTop: 20,
  },
});

export default App;
