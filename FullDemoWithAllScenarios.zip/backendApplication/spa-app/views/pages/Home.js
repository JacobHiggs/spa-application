import expensesApi from "../../services/expensesApi.js";

const Home = {
  allowAccess: async () => true,
  render: async () => {
    const summary = await expensesApi.getTotals();
    const view = /*html*/ `
    <h1>Bank Application</h1>
    <p id="user-greet">Hello, ${window.user.name}</p>
    <p>Welcome to the banking application</p>

    ${window.errorDetails}

    `;
    return view;
  },
  postRender: async () => { },
};

export default Home;
