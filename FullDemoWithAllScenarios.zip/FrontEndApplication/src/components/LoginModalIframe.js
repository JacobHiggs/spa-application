import React, { useState } from 'react';

const LoginModal3 = () => {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <button onClick={() => setShowModal(true)}>Login with Modal Scenario2B</button>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)} style={overlayStyle}>
          <div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
            style={modalStyle}
          >
            <h3>Embedded App</h3>
            <iframe
              src="http://localhost:3001/"
              title="Embedded Login App"
              style={iframeStyle}
            />
            <button onClick={() => setShowModal(false)} style={{ marginTop: '10px' }}>
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};

// 🔧 Simple inline styles (optional: move to CSS)
const overlayStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000
};

const modalStyle = {
  backgroundColor: 'white',
  padding: '20px',
  borderRadius: '8px',
  maxWidth: '800px',
  width: '90%',
  maxHeight: '90vh',
  overflow: 'hidden',
  boxShadow: '0 2px 10px rgba(0,0,0,0.3)'
};

const iframeStyle = {
  width: '100%',
  height: '600px',
  border: 'none'
};

export default LoginModal3;
