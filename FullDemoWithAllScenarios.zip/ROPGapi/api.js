require('dotenv').config();
const express = require('express');
const ClientOAuth2 = require('client-oauth2');
const axios = require('axios');
const path = require('path');

const cors = require('cors');


const app = express();
app.use(cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true })); // Middleware to parse JSON body


// Configure OAuth2 ROPC Client
const ropcAuth = new ClientOAuth2({
  clientId: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  accessTokenUri: process.env.OAUTH_TOKEN_URL
});

// Login Route
app.post('/start', async (req, res) => {

  console.log(`Start Request Recieved`);

  const { username } = req.body;

  console.log(username);

  const clientId = 'Sflii0gup2Gjg65gsmj6Yfrs737BbVml'; // Replace with your Auth0 client ID
  const domain = 'jacoblogin.acmetest.org'; // Replace with your Auth0 domain
  const audience = ''; // Optional
  const scope = 'openid profile email'; // Customize as needed


  try {
    const res2 = await fetch(`https://${domain}/passwordless/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        phone_number: username,
        connection: "sms",
        send: "code",
        client_id: clientId
      })
    });

    const data = await res2.json();

    if (res2.ok) {
      console.log("Access Token: " + data.access_token);
      return res.json({
        loginStatus: "Code Sent"
      });
    } else {
      console.log(res2.json)
      return res.json({
        loginStatus: "Failed"
      });
    }
  } catch (err) {
    console.error(err);
    return res.json({
      loginStatus: "Failed"
    });
  }
});

// Login Route
app.post('/login', async (req, res) => {

  console.log(`Login Request Recieved`);

  const { username, code } = req.body;

  const clientId = 'Sflii0gup2Gjg65gsmj6Yfrs737BbVml'; // Replace with your Auth0 client ID
  const domain = 'jacoblogin.acmetest.org'; // Replace with your Auth0 domain
  const audience = ''; // Optional
  const scope = 'openid profile email'; // Customize as needed

  try {
    const res2 = await fetch(`https://${domain}/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grant_type: 'http://auth0.com/oauth/grant-type/passwordless/otp',
        username,
        otp: code,
        realm: "sms",
        scope,
        client_id: clientId
      })
    });

    const data = await res2.json();

    if (res2.ok) {
      console.log("Access Token: " + data.access_token);
      return res.json({
        loginStatus: "Success"
      });
    } else {
      console.log(res2.json)
      return res.json({
        loginStatus: "Failed"
      });
    }
  } catch (err) {
    console.error(err);
    return res.json({
      loginStatus: "Failed"
    });
  }
});

// Submit OTP Route
app.post('/otp', async (req, res) => {
  const { otp, mfa_token, oob_code } = req.body;

  console.log(`OTP Request Recieved`);

  if (!otp || !mfa_token || !oob_code) {
    return res.status(400).json({ error: 'OTP, MFA Token, and OOB code are required' });
  }

  var options = {
    method: 'POST',
    url: process.env.OAUTH_TOKEN_URL,
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    data: new URLSearchParams({
      grant_type: 'http://auth0.com/oauth/grant-type/mfa-oob',
      client_id: process.env.CLIENT_ID,
      client_secret: process.env.CLIENT_SECRET,
      mfa_token: mfa_token,
      oob_code: oob_code,
      binding_code: otp
    })
  };

  axios.request(options).then(function (response) {
    console.log(response.data);
    return res.redirect('/success?access_token=' + encodeURIComponent(response.data.access_token) + '&id_token=' + encodeURIComponent(response.data.id_token));
  }).catch(function (error) {
    console.log("An error occurred");
    console.error(error);
    return res.status(401).json({ error: 'Error occurred with MFA Service', details: error.message });
  });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/mfa', (req, res) => {
  res.sendFile(path.join(__dirname, 'mfa.html'));
});

app.get('/success', (req, res) => {
  res.sendFile(path.join(__dirname, 'success.html'));
});

app.get('/static/jwp/css/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const publicDirectory = path.join(__dirname, 'public');
app.use(express.static(publicDirectory));


// Start the server
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`✅ Servers running on port ${PORT}`));
